# Nguồn của agent `agency-marketing-carousel-growth-engine`

Một agent lẻ của gói `javis.agency-agents`, lấy từ [msitarzewski/agency-agents/marketing/marketing-carousel-growth-engine.md](https://github.com/msitarzewski/agency-agents/blob/main/marketing/marketing-carousel-growth-engine.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Javis (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Javis báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
