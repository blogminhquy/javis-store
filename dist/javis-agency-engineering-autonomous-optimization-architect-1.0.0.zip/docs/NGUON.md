# Nguồn của agent `agency-engineering-autonomous-optimization-architect`

Một agent lẻ của gói `javis.agency-agents`, lấy từ [msitarzewski/agency-agents/engineering/engineering-autonomous-optimization-architect.md](https://github.com/msitarzewski/agency-agents/blob/main/engineering/engineering-autonomous-optimization-architect.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Javis (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Javis báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
