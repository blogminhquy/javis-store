# Nguồn của gói theo repo gốc `lemomo-ai/lemo-opuscar`

Skill trong gói này chép **nguyên văn** từ [lemomo-ai/lemo-opuscar](https://github.com/lemomo-ai/lemo-opuscar), nhánh `main`:
không dịch, không rút gọn, không sửa frontmatter.

Mỗi ngày kho so lại với repo gốc (`tools/theo-goc.py`). Repo gốc đổi thì gói lên một bản
vá, Javis báo trong chuông và bạn bấm Cập nhật. Skill bạn đã tự sửa thì Javis giữ lại,
không ghi đè. Commit gốc của bản đang phát hành nằm ở trường `upstream.commit` trong
`index.json`.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*` nếu repo có.

| Skill | Thư mục gốc |
|---|---|
| `lemo-opuscar` | `plugin/skills/lemo-opuscar` |
