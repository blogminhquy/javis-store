# Nguồn của agent `agency-paid-media-creative-strategist`

Một agent lẻ của gói `javis.agency-agents`, lấy từ [msitarzewski/agency-agents/paid-media/paid-media-creative-strategist.md](https://github.com/msitarzewski/agency-agents/blob/main/paid-media/paid-media-creative-strategist.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Javis (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Javis báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
